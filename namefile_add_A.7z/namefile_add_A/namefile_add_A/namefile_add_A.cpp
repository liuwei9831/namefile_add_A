#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<string>
using namespace std;
int main()
{
	FILE* fp;
	FILE* fw;
	char str[100] = { 0 };
	fp = fopen("m1.txt", "r");
	fw = fopen("m12.txt", "w");
	while (fgets(str, sizeof(str), fp))
	{
		printf("����%d\n", strlen(str));
		if (str[strlen(str)] != -1 && strlen(str) != 1)
		{
			if (str[strlen(str) - 1] == 10)
			{
				str[strlen(str) - 1] = ' ';
				strcat(str, "A\n");
			}
			else {
				str[strlen(str)] = ' ';
				strcat(str, "A");
			}

		}
		fputs(str, fw);
	}
	fclose(fp);
	fclose(fw);
}